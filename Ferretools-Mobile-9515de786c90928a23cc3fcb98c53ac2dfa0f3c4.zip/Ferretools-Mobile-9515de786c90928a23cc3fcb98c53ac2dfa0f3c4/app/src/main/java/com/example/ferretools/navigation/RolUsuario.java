package com.example.ferretools.navigation;

public enum RolUsuario {
    NINGUNO,
    ADMIN,
    CLIENTE,
    ALMACENERO
}
