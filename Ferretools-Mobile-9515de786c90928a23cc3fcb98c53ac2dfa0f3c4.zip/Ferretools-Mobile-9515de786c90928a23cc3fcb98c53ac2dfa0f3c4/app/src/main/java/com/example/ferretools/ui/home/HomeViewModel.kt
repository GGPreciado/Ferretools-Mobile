package com.example.ferretools.ui.home

import androidx.lifecycle.ViewModel

class HomeViewModel : ViewModel() {
    // Add home screen specific state and logic here
} 