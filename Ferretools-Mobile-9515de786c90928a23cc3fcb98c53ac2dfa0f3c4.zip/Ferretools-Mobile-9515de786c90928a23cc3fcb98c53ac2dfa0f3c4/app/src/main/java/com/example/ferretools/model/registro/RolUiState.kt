package com.example.ferretools.model.registro

import com.example.ferretools.model.enums.RolUsuario

data class RolUiState(
    var rolUsuario: RolUsuario? = null
)