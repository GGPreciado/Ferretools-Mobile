package com.example.ferretools.model.database

data class Categoria(
    val nombre: String ="",
)
