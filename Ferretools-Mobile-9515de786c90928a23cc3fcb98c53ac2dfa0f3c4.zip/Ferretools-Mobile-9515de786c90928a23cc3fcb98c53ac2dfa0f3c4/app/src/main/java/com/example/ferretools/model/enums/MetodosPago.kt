package com.example.ferretools.model.enums

enum class MetodosPago {
    Yape,
    Efectivo,
}